from django.contrib import admin
from .models import IotSubDev
# Register your models here.

admin.site.register(IotSubDev)