from django.conf.urls import include, url

from rest_framework_nested import routers
from .views import DeviceViewSet,CtrlChannelViewSet,MetricDataViewSet,DataChannelViewSet,MeasurementViewSet

from django.conf import settings
router = routers.SimpleRouter()
router.register(r'devices', DeviceViewSet,base_name='devices')
#先创建一个路由实例，再注册一个url
#第一级URL

device_router = routers.NestedSimpleRouter(router, r'devices', lookup='devices')
# /devices/****/ctrlchannels/***/metricdata/**
device_router.register(r'ctrlchannels', CtrlChannelViewSet, base_name='ctrlchannels')
device_router.register(r'datachannels', DataChannelViewSet, base_name='datachannels')

ctrlchannel_router = routers.NestedSimpleRouter(device_router,r'ctrlchannels',lookup='ctrlchannels')
ctrlchannel_router.register(r'metricdata',MetricDataViewSet,base_name='metricdata')

datachannel_router = routers.NestedSimpleRouter(device_router,r'datachannels',lookup='datachannels')
datachannel_router.register(r'measurements',MeasurementViewSet,base_name='measurements')

urlpatterns = [
    url(r'^', include(router.urls)),
    url(r'^', include(device_router.urls)),
    url(r'^', include(ctrlchannel_router.urls)),
    url(r'^', include(datachannel_router.urls)),
]