# myDialogWin.py
import sys
from PyQt6.QtWidgets import QWidget, QApplication, QFileDialog
from DialogWin import Ui_Form
from PyQt6.QtCore import QDir


class QmyWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)  # 调用父类构造函数，创建QWidget窗口
        self.__ui = Ui_Form()  # 创建UI对象
        self.__ui.setupUi(self)  # 构造UI界面
        self.setWindowTitle("对话框程序")

    def on_pushButton_openfile_pressed(self):
        currentPath = QDir.currentPath()
        dialogTitle = "选择一个文件"
        formatFilter = "所有文件(*.*);;文本文件(*.txt);;图片文件(*.jpg *.gif *.png)"
        fileName, filterUsed = QFileDialog.getOpenFileName(
            self, dialogTitle, currentPath, formatFilter)
        self.__ui.plainTextEdit_file.appendPlainText(fileName)
        self.__ui.plainTextEdit_file.appendPlainText("\n"+filterUsed)

    def on_pushButton_openfiles_pressed(self):
        currentPath = QDir.currentPath()
        dialogTitle = "选择多个文件"
        formatFilter = "所有文件(*.*);;文本文件(*.txt);;图片文件(*.jpg *.gif *.png)"
        fileList, filterUsed = QFileDialog.getOpenFileNames(
            self, dialogTitle, currentPath, formatFilter)
        for file in fileList:
            self.__ui.plainTextEdit_file.appendPlainText(file)
        self.__ui.plainTextEdit_file.appendPlainText("\n"+filterUsed)

    def on_pushButton_dir_pressed(self):
        currentPath = QDir.currentPath()
        dialogTitle = "选择一个目录"
        selectedDir = QFileDialog.getExistingDirectory(
            self, dialogTitle, currentPath, QFileDialog.Option.ShowDirsOnly)
        self.__ui.plainTextEdit_file.appendPlainText("\n"+selectedDir)

    def on_pushButton_savefile_pressed(self):
        currentPath = QDir.currentPath()
        dialogTitle = "保存文件"
        formatFilter = "所有文件(*.*);;文本文件(*.txt);;图片文件(*.jpg *.gif *.png)"
        fileName, filterUsed = QFileDialog.getSaveFileName(
            self, dialogTitle, currentPath, formatFilter)
        self.__ui.plainTextEdit_file.appendPlainText(fileName)
        self.__ui.plainTextEdit_file.appendPlainText("\n"+filterUsed)


if __name__ == "__main__":
    app = QApplication(sys.argv)  # 创建App，用QApplication类
    myWidget = QmyWidget()
    myWidget.show()
    sys.exit(app.exec())
