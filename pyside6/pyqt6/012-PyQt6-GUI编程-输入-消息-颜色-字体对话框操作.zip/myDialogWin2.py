# myDialogWin2.py
import sys
from PyQt6.QtWidgets import QWidget, QApplication, QLineEdit, QInputDialog, QMessageBox, QColorDialog,QFontDialog
from click import echo 
from DialogWin2 import Ui_Form
from PyQt6.QtCore import QDir
from PyQt6.QtGui import QPalette


class QmyWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)  # 调用父类构造函数，创建QWidget窗口
        self.__ui = Ui_Form()  # 创建UI对象
        self.__ui.setupUi(self)  # 构造UI界面
        self.setWindowTitle("对话框程序2")

    def on_pushButton_inputchar_pressed(self):
        dialogTitle = "输入字符串文字对话框"
        textlabel = "请输入文件名"
        defaultinput = "新建文件.txt"
        echomode = QLineEdit.EchoMode.Normal
        text, OK = QInputDialog.getText(self,dialogTitle,textlabel,echomode,defaultinput)
        if (OK):
            self.__ui.plainTextEdit.appendPlainText(text)

    def on_pushButton_inputint_pressed(self):
        dialogTitle = "输入整数对话框"
        textlabel = "设置字体大小"
        defaultValue = self.__ui.plainTextEdit.font().pointSize()
        minValue = 6
        maxValue = 50
        stepValue = 1
        inputValue, OK = QInputDialog.getInt(self,dialogTitle,textlabel,defaultValue,minValue,maxValue,stepValue)
        if (OK):
            font = self.__ui.plainTextEdit.font()
            font.setPointSize(inputValue)
            self.__ui.plainTextEdit.setFont(font)

    def on_pushButton_inputfloat_pressed(self):
        dialogTitle = "输入浮点数对话框"
        textlabel = "输入一个浮点数"
        defaultValue = 3.14
        minValue = 0
        maxValue = 10000
        decimals = 2
        inputValue, OK = QInputDialog.getDouble(self,dialogTitle,textlabel,defaultValue,minValue,maxValue,decimals)
        if (OK):
            text = "输入了一个浮点数： %.2f"%inputValue
            self.__ui.plainTextEdit.appendPlainText(text)

    def on_pushButton_inputitem_pressed(self):
        dialogTitle = "条目选择对话框"
        textlabel = "请选择级别"
        currentIndex = 0
        editable = True
        items = ["优秀","良好","合格","不合格"]
        text, OK = QInputDialog.getItem(self,dialogTitle,textlabel,items,currentIndex,editable)
        if (OK):
            self.__ui.plainTextEdit.appendPlainText(text)

    def on_pushButton_question_pressed(self):
        dialogTitle = "Question对话框"
        textlabel = "已被修改，是否保存修改"
        defaultButton = QMessageBox.StandardButton.NoButton
        result = QMessageBox.question(self,dialogTitle,textlabel,QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No |QMessageBox.StandardButton.Cancel,defaultButton)
        if (result == QMessageBox.StandardButton.Yes):
            self.__ui.plainTextEdit.appendPlainText("Yes")
        elif (result == QMessageBox.StandardButton.No):
            self.__ui.plainTextEdit.appendPlainText("No")
        elif (result == QMessageBox.StandardButton.Cancel):
            self.__ui.plainTextEdit.appendPlainText("Cancel")
        else:
            self.__ui.plainTextEdit.appendPlainText("无选择")

    def on_pushButton_information_pressed(self):
        dialogTitle = "Information对话框"
        textlabel = "数据已保存"
        QMessageBox.information(self,dialogTitle,textlabel)

    def on_pushButton_warning_pressed(self):
        dialogTitle = "Warning对话框"
        textlabel = "数据已被修改"
        QMessageBox.warning(self,dialogTitle,textlabel)

    def on_pushButton_error_pressed(self):
        dialogTitle = "Critical对话框"
        textlabel = "出现错误"
        QMessageBox.critical(self,dialogTitle,textlabel)

    def on_pushButton_color_pressed(self):
        palette = self.__ui.plainTextEdit.palette() #获取现有的调色板
        iniColor = palette.color(QPalette.ColorRole.Text) #现有的文本颜色
        color = QColorDialog.getColor(iniColor,self, "选择颜色") #打开颜色对话框
        if (color.isValid()):
            palette.setColor(QPalette.ColorRole.Text,color) #设置选择的颜色
            self.__ui.plainTextEdit.setPalette(palette) #设置调色板

    def on_pushButton_font_pressed(self):
        iniFont = self.__ui.plainTextEdit.font()
        font,OK = QFontDialog.getFont(iniFont)
        if (OK):
            self.__ui.plainTextEdit.setFont(font)

if __name__ == "__main__":
    app = QApplication(sys.argv)  # 创建App，用QApplication类
    myWidget = QmyWidget()
    myWidget.show()
    sys.exit(app.exec())
