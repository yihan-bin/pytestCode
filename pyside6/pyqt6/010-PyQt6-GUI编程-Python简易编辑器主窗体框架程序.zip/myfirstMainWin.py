# audioMainWin.py
import sys
from PyQt6.QtWidgets import QMainWindow, QApplication
from PyQt6.QtCore import Qt, pyqtSlot
from PyQt6.QtGui import QFont
from MainWindow import Ui_MainWindow


class QmyMainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)  # 调用父类构造函数，创建QWidget窗口
        self.__ui = Ui_MainWindow()  # 创建UI对象
        self.__ui.setupUi(self)  # 构造UI界面
        self.setWindowTitle("我的主窗口")
        self.setCentralWidget(self.__ui.plainTextEdit)
        self.__ui.statusbar.showMessage("这里是状态栏")

    # ===========由connectSlotsByName() 自动连接的槽函数=====================
    @pyqtSlot(bool)   ##设置粗体 
    def on_actionEditBold_triggered(self, checked):   
        format=self.__ui.plainTextEdit.currentCharFormat()
        if (checked == True):
            format.setFontWeight(QFont.Weight.Bold)
        else:
            format.setFontWeight(QFont.Weight.Normal)
        self.__ui.plainTextEdit.mergeCurrentCharFormat(format)

    @pyqtSlot(bool)   ##设置斜体 
    def on_actionEditItalic_triggered(self,checked):    
        format=self.__ui.plainTextEdit.currentCharFormat()
        format.setFontItalic(checked)
        self.__ui.plainTextEdit.mergeCurrentCharFormat(format)
            
    @pyqtSlot(bool)     ##设置下划线 
    def on_actionEditUnderline_triggered(self,checked):  
        format=self.__ui.plainTextEdit.currentCharFormat()
        format.setFontUnderline(checked)
        self.__ui.plainTextEdit.mergeCurrentCharFormat(format)

    def on_plainTextEdit_copyAvailable(self, txt): ##文本框内容可copy
      self.__ui.actionEditCut.setEnabled(txt)
      self.__ui.actionEditCopy.setEnabled(txt)
      self.__ui.actionEditPaste.setEnabled(self.__ui.plainTextEdit.canPaste())
                                         
    def on_plainTextEdit_selectionChanged(self):     ##文本选择内容发生变化
        format=self.__ui.plainTextEdit.currentCharFormat()
        self.__ui.actionEditBold.setChecked(format.font().bold())
        self.__ui.actionEditItalic.setChecked(format.fontItalic())
        self.__ui.actionEditUnderline.setChecked(format.fontUnderline())

    def on_plainTextEdit_customContextMenuRequested(self,pos):  ##标准右键菜单
        popMenu=self.__ui.plainTextEdit.createStandardContextMenu()
        popMenu.exec(pos) #显示快捷菜单


if __name__ == "__main__":
    app = QApplication(sys.argv)  # 创建App，用QApplication类
    myWidget = QmyMainWindow()
    myWidget.show()
    sys.exit(app.exec())
